# food.txt
Food is good
